import { connect } from "react-redux"
import Greeting from "./greeting"

const mapStateToProps = (state) => ({

})

const mapDispatchToProps = (dispatch) => ({

})

export default connect(mapStateToProps, mapDispatchToProps)(Greeting)