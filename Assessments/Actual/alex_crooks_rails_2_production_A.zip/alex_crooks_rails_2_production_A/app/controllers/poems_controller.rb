class PoemsController < ApplicationController
    before_action :require_logged_in, only:[:create, :update, :index]
    
    def new
        if logged_in?
            render :new
        else
            redirect_to new_session_url
        end
    end

    def index
        @poems = current_user.poems.all
        render :index
    end

    def create
        @poem = Poem.create(poem_params)
        # @poem.user_id = current_user.id
        if @poem.save && logged_in?
            redirect_to poems_url
        else
            flash[:errors] = ["Stanzas can't be blank"]
            render :new
        end
    end

    def edit
        if logged_in?
            render :edit
        else
            redirect_to new_session_url
        end
    end

    def update
        @poem = current_user.poems.find_by(id: params[:id])
        if @poem
            render :edit
        else
            flash[:errors] = ["Something went wrong!"]
        end
    end

    def poem_params
        params.require(:poem).permit(:title, :stanza, :complete)
    end
end
