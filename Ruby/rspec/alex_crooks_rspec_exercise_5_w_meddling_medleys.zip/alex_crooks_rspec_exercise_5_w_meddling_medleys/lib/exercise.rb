def zip(*arrays)
    length = arrays.first.length
    (0...length).map do |ele|
    arrays.map {|i| i[ele]}
    end
end

def prizz_proc(array, prc_1, prc_2)
    new_arr = []
    array.each do |i|
    new_arr << i if (prc_1.call(i) || prc_2.call(i)) && !(prc_1.call(i) && prc_2.call(i))
    end
    new_arr
end

def zany_zip(*arrays)
    length = arrays.length
    count = 0
    arrays.each do |i|
        count = i.length if i.length > count
    end
    (0...count).map do |ele|
    arrays.map {|i| 
    if i[ele] != nil
        i[ele]
    else
        nil
    end
    }
end
end

def maximum(array, &prc)
    return nil if array.length == 0
    max = array.first
    array.each do |ele|
        max = ele if prc.call(ele) >= prc.call(max)
    end
    max   
end

def my_group_by(array, &block)
    hash = Hash.new {|h,k| h[k] = []}
    array.each do |ele|
        hash[block.call(ele)] << ele
    end
    hash
end

def max_tie_breaker(array, prc, &block)
    return nil if array.empty? == 0
    max = array.first
    array.each do |ele|
        if block.call(ele) > block.call(max)
            max = ele
        elsif block.call(ele) == block.call(max) && prc.call(ele) > prc.call(max)
                max = ele
        end
    end
    max
end

def silly_syllables(sent)
    new_sent = []
    vowels = "aeiou"
    sent.split(" ").each.with_index do |word, i|
        counter = 0
        word.each_char do |char|
        counter += 1 if vowels.include?(char)
        end
        if counter > 1
            new_sent << vowel_remover(vowel_remover(word.reverse).reverse)
        else
            new_sent << word
        end
    end
    new_sent.join(" ")
end

def vowel_remover(word)
    word.each_char.with_index do |char, idx|
        return word[idx..-1] if "aeiou".include?(char)
    end
end
