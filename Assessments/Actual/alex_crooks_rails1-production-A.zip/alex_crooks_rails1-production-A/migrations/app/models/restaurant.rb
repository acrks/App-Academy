class Restaurant < ApplicationRecord
  
end
