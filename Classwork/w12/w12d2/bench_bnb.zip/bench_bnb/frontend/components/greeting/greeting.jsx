import React from "react";

class Greeting extends React.Component {
    constructor(props){
        super(props);
    }

    render(){
        return(
            null
        )
    }
}

export default Greeting;