class Board
    attr_reader :size
    def initialize(size)
        @size = size
        @grid = Array.new(@size) {Array.new(@size)} 
    end

    def [](pos)
        row, col = pos
        return @grid[row][col]
    end

    def []=(pos,mark)
        row, col = pos
        @grid[row][col] = mark
    end

    def complete_row?(mark)
        @grid.any? {|i| i.all? {|j| j == mark}}
    end

    def complete_col?(mark)
        @grid.transpose.any? {|i| i.all? {|j| j == mark}}
    end

    def complete_diag?(mark)
        arr = []
        n = @grid.length - 1
        i = 0
        while i < @grid.length
            arr << @grid[n][i]
            i += 1
            n -= 1
        end
        return (0...@grid.length).all? {|i| @grid[i][i] == mark} || arr.all? {|j| j == mark}
    end

    def winner?(mark)
        complete_col?(mark) || complete_row?(mark) || complete_diag?(mark)
    end
    # This Board#print method is given for free and does not need to be modified
    # It is used to make your game playable.
    def print
        @grid.each { |row| p row }
    end
end
